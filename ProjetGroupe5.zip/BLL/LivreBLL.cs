﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class LivreBLL
    {
        public int id { get; set; }
        public string nomLiv { get; set; }
        public string codeLiv { get; set; }
        public string auteurLiv { get; set; }
        public string Available { get; set; }
        public string NPages { get; set; }
        public string APublic { get; set; }
    }
}
