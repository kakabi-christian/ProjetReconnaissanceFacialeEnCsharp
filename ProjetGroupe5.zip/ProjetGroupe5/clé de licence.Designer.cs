﻿namespace ProjetGroupe5
{
    partial class clé_de_licence
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_jours = new System.Windows.Forms.TextBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.rdbc = new System.Windows.Forms.RadioButton();
            this.txt_jrs_restant = new System.Windows.Forms.TextBox();
            this.txt_date_expiration = new System.Windows.Forms.TextBox();
            this.txt_date_cration = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_cle_produit = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_id = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_activer = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_jours
            // 
            this.txt_jours.Location = new System.Drawing.Point(552, 72);
            this.txt_jours.Name = "txt_jours";
            this.txt_jours.ReadOnly = true;
            this.txt_jours.Size = new System.Drawing.Size(244, 22);
            this.txt_jours.TabIndex = 30;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(425, 68);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(85, 21);
            this.radioButton2.TabIndex = 28;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Partiale";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // rdbc
            // 
            this.rdbc.AutoSize = true;
            this.rdbc.Location = new System.Drawing.Point(248, 68);
            this.rdbc.Name = "rdbc";
            this.rdbc.Size = new System.Drawing.Size(96, 21);
            this.rdbc.TabIndex = 29;
            this.rdbc.TabStop = true;
            this.rdbc.Text = "Complète";
            this.rdbc.UseVisualStyleBackColor = true;
            // 
            // txt_jrs_restant
            // 
            this.txt_jrs_restant.Location = new System.Drawing.Point(248, 237);
            this.txt_jrs_restant.Name = "txt_jrs_restant";
            this.txt_jrs_restant.ReadOnly = true;
            this.txt_jrs_restant.Size = new System.Drawing.Size(548, 22);
            this.txt_jrs_restant.TabIndex = 23;
            // 
            // txt_date_expiration
            // 
            this.txt_date_expiration.Location = new System.Drawing.Point(248, 196);
            this.txt_date_expiration.Name = "txt_date_expiration";
            this.txt_date_expiration.ReadOnly = true;
            this.txt_date_expiration.Size = new System.Drawing.Size(548, 22);
            this.txt_date_expiration.TabIndex = 24;
            // 
            // txt_date_cration
            // 
            this.txt_date_cration.Location = new System.Drawing.Point(248, 153);
            this.txt_date_cration.Name = "txt_date_cration";
            this.txt_date_cration.ReadOnly = true;
            this.txt_date_cration.Size = new System.Drawing.Size(548, 22);
            this.txt_date_cration.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 240);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 17);
            this.label6.TabIndex = 16;
            this.label6.Text = "Jours restants";
            // 
            // txt_cle_produit
            // 
            this.txt_cle_produit.Location = new System.Drawing.Point(248, 112);
            this.txt_cle_produit.Name = "txt_cle_produit";
            this.txt_cle_produit.Size = new System.Drawing.Size(548, 22);
            this.txt_cle_produit.TabIndex = 26;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 199);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 17);
            this.label5.TabIndex = 17;
            this.label5.Text = "Date d\'expiration";
            // 
            // txt_id
            // 
            this.txt_id.Location = new System.Drawing.Point(248, 17);
            this.txt_id.Name = "txt_id";
            this.txt_id.ReadOnly = true;
            this.txt_id.Size = new System.Drawing.Size(548, 22);
            this.txt_id.TabIndex = 27;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 156);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 17);
            this.label2.TabIndex = 18;
            this.label2.Text = "Date de creation";
            // 
            // btn_activer
            // 
            this.btn_activer.Location = new System.Drawing.Point(647, 282);
            this.btn_activer.Name = "btn_activer";
            this.btn_activer.Size = new System.Drawing.Size(150, 52);
            this.btn_activer.TabIndex = 22;
            this.btn_activer.Text = "Activer";
            this.btn_activer.UseVisualStyleBackColor = true;
            this.btn_activer.Click += new System.EventHandler(this.btn_activer_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 17);
            this.label3.TabIndex = 19;
            this.label3.Text = "Clé de produit";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 17);
            this.label4.TabIndex = 20;
            this.label4.Text = "ID du produit";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 17);
            this.label1.TabIndex = 21;
            this.label1.Text = "type de licence";
            // 
            // clé_de_licence
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(845, 349);
            this.Controls.Add(this.txt_jours);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.rdbc);
            this.Controls.Add(this.txt_jrs_restant);
            this.Controls.Add(this.txt_date_expiration);
            this.Controls.Add(this.txt_date_cration);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_cle_produit);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_id);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_activer);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold);
            this.Name = "clé_de_licence";
            this.Text = "clé_de_licence";
            this.Load += new System.EventHandler(this.clé_de_licence_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_jours;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton rdbc;
        public System.Windows.Forms.TextBox txt_jrs_restant;
        public System.Windows.Forms.TextBox txt_date_expiration;
        public System.Windows.Forms.TextBox txt_date_cration;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox txt_cle_produit;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox txt_id;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_activer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
    }
}