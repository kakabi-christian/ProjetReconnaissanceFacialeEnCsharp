﻿namespace ProjetGroupe5
{
    partial class OptionDémarrage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTitreOption = new System.Windows.Forms.Panel();
            this.lblQuitter = new System.Windows.Forms.Label();
            this.lblTitreOption = new System.Windows.Forms.Label();
            this.btnAdministrateur = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pnlTitreOption.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTitreOption
            // 
            this.pnlTitreOption.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.pnlTitreOption.Controls.Add(this.lblQuitter);
            this.pnlTitreOption.Controls.Add(this.lblTitreOption);
            this.pnlTitreOption.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTitreOption.Location = new System.Drawing.Point(0, 0);
            this.pnlTitreOption.Name = "pnlTitreOption";
            this.pnlTitreOption.Size = new System.Drawing.Size(338, 90);
            this.pnlTitreOption.TabIndex = 0;
            // 
            // lblQuitter
            // 
            this.lblQuitter.AutoSize = true;
            this.lblQuitter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblQuitter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblQuitter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblQuitter.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblQuitter.ForeColor = System.Drawing.Color.White;
            this.lblQuitter.Location = new System.Drawing.Point(303, 9);
            this.lblQuitter.Name = "lblQuitter";
            this.lblQuitter.Size = new System.Drawing.Size(23, 21);
            this.lblQuitter.TabIndex = 1;
            this.lblQuitter.Text = "X";
            this.lblQuitter.Click += new System.EventHandler(this.lblQuitter_Click);
            // 
            // lblTitreOption
            // 
            this.lblTitreOption.AutoSize = true;
            this.lblTitreOption.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lblTitreOption.ForeColor = System.Drawing.Color.White;
            this.lblTitreOption.Location = new System.Drawing.Point(103, 24);
            this.lblTitreOption.Name = "lblTitreOption";
            this.lblTitreOption.Size = new System.Drawing.Size(131, 46);
            this.lblTitreOption.TabIndex = 0;
            this.lblTitreOption.Text = "   OPTION \r\nCONNEXION";
            // 
            // btnAdministrateur
            // 
            this.btnAdministrateur.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.btnAdministrateur.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdministrateur.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnAdministrateur.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdministrateur.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.btnAdministrateur.ForeColor = System.Drawing.Color.White;
            this.btnAdministrateur.Location = new System.Drawing.Point(58, 293);
            this.btnAdministrateur.Name = "btnAdministrateur";
            this.btnAdministrateur.Size = new System.Drawing.Size(204, 75);
            this.btnAdministrateur.TabIndex = 1;
            this.btnAdministrateur.Text = "ADMINISTRATEUR";
            this.btnAdministrateur.UseVisualStyleBackColor = false;
            this.btnAdministrateur.Click += new System.EventHandler(this.btnAdministrateur_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(72, 166);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(172, 75);
            this.button2.TabIndex = 1;
            this.button2.Text = "UTILISATEUR";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // OptionDémarrage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(338, 421);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnAdministrateur);
            this.Controls.Add(this.pnlTitreOption);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "OptionDémarrage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OptionDémarrage";
            this.pnlTitreOption.ResumeLayout(false);
            this.pnlTitreOption.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTitreOption;
        private System.Windows.Forms.Label lblQuitter;
        private System.Windows.Forms.Label lblTitreOption;
        private System.Windows.Forms.Button btnAdministrateur;
        private System.Windows.Forms.Button button2;
    }
}